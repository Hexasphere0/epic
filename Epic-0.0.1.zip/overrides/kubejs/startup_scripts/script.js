onEvent('item.registry', event => {
    event.create("tanned_leather")
    event.create("tanned_leather_strips")
    event.create("woven_tanned_leather")
})